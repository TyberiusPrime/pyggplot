class _PlotBase(object):
    pass
